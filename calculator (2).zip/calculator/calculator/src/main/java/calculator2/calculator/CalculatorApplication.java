package calculator2.calculator;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.Scanner;

@SpringBootApplication
public class CalculatorApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(CalculatorApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        double num1 = 0;
        double num2 = 0;
        char operator = ' ';

        System.out.print("\n-- Welcome To Simple Calculator ---\n");

        // First number
        while (true) {
            System.out.println("Enter a number to start calculation: ");
            if (scanner.hasNextDouble()) {
                num1 = scanner.nextDouble();
                scanner.nextLine();
                break;
            } else {
                System.out.println("Invalid input! Please make sure you entered a number.");
                scanner.nextLine();
            }
        }

        // Operator
        while (true) {
            System.out.println("Enter an operator (+, -, *, /): ");
            String input = scanner.nextLine();
            if (!input.isEmpty()) {
                operator = input.charAt(0);
                if (operator == '+' || operator == '-' || operator == '*' || operator == '/') {
                    break;
                }
            }
            System.out.println("Invalid operator. Please enter one of +, -, *, /");
        }

        // Second number
        while (true) {
            System.out.println("Enter a 2nd number: ");
            if (scanner.hasNextDouble()) {
                num2 = scanner.nextDouble();
                scanner.nextLine();
                if (operator == '/' && num2 == 0) {
                    System.out.println("Invalid input! You cannot divide by zero.");
                    continue;
                }
                break;
            } else {
                System.out.println("Invalid input! Please make sure you entered a number.");
                scanner.nextLine();
            }
        }

        // Compute
        System.out.print("Equals: ");
        switch (operator) {
            case '+':
                System.out.println(num1 + num2);
                break;
            case '-':
                System.out.println(num1 - num2);
                break;
            case '*':
                System.out.println(num1 * num2);
                break;
            case '/':
                System.out.println(num1 / num2);
                break;
            default:
                System.out.println("Invalid Input! Please make sure you entered a mathematical operator.");
        }

        System.out.print("\n-- Thank you, now Simple calculator will close ---\n");
        scanner.close();

        // Terminate the Spring application after the console run
        System.exit(0);
    }
}

